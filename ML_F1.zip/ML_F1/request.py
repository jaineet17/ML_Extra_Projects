import requests

url = 'http://localhost:5000/results'
r = requests.post(url,json={'open_price':2450, 'high_price':2542, 'low_price': 2431, 'volume': 5572})

print(r.json())