import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn import preprocessing
from sklearn import metrics
from sklearn.metrics import r2_score
from sklearn.linear_model import Ridge
import pickle
from sklearn.preprocessing import MinMaxScaler

df = pd.read_excel("/Users/jaineet/Desktop/Nirma/SEM-5/Machine Learning/IA-2/Train_Data.xlsx")
df = df.rename(columns={'Adj Close': 'Close'})

df.dropna(inplace=True)

x = np.array(df[['Open','High','Low','Volume']])
y = np.array(df[['Close']])

x_train, x_test, y_train, y_test = train_test_split( x, y, test_size=0.4, random_state=4)

scaler = MinMaxScaler(feature_range=(0, 1))
x_train = scaler.fit_transform(x_train)
y_train = scaler.fit_transform(y_train)

clf = Ridge(alpha=10,solver = 'lsqr' )

clf.fit(x_train, y_train)

pickle.dump(clf, open('model.pkl','wb'))

model = pickle.load(open('model.pkl','rb'))